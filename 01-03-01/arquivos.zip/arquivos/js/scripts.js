function formatarValor(valor) {
    valor = parseFloat(valor)
    return valor.toLocaleString('pt-br', {minimumFractionDigits: 2});
}